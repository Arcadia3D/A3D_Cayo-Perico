fx_version 'cerulean'

games 'gta5'

this_is_a_map 'yes' 

author 'Arcadia3D <Arcadia3D#7993>'

description 'Cayo Perico Map - Alpha'

version '1.0.0'