ITA: Questa mappa verrà aggiornata ogni settimana.

Versione 1.0

-Aggiunto benzinaio vicino l'hangar.



ENG: This map will recive an update every week.

Version 1.0

-Added a gas Station near the hangar.